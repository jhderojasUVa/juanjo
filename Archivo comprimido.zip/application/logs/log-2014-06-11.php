<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-06-11 12:40:02 --> Severity: Warning  --> date() expects at least 1 parameter, 0 given /httpdocs/juanjo/application/models/menu.php 13
ERROR - 2014-06-11 12:45:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.posicion FROM menu, platos WHERE menu.idplato=platos.idplato AND fecha='2014-06' at line 1
ERROR - 2014-06-11 13:04:02 --> 404 Page Not Found --> principal/juanjo
ERROR - 2014-06-11 13:13:42 --> 404 Page Not Found --> principal/juanjo
