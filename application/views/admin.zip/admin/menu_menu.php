<!DOCTYPE html>
<html lang="es">
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
</head>
<body>
<? if (count($menu)!=0 ) { ?>
		<table width="100%">
    	<? $antiguo_pos = 0; ?>
        <? foreach ($menu as $row) { ?>
        <form action="<?=base_url()?>index.php/ws/del_plato_menu" method="post">
        <input type="hidden" name="fecha" value="<?=$fecha?>" />
        <input type="hidden" name="idplato" value="<?=$row -> idplato?>" />
        <input type="hidden" name="posicion" value="<?=$row -> posicion?>" />
			<tr>
			<? $nuevo_pos = $row -> posicion; ?>
            <? if ($antiguo_pos!=$nuevo_pos) { ?>
                <td class="fondo">De <?=$row -> posicion?>&deg;</td>
                <? $antiguo_pos = $nuevo_pos; ?> 
            <? } else { ?>
            	<td></td>
            <? } ?>
            	<td class="fondo"><?=$row -> plato?> <input type="submit" value="eliminar" /></td>
            </tr>
        </form>
        <? } ?>
        </table>
<? } else { ?>
	<p>Aun no hay ningun plato en el menu</p>
<? } ?>
</body>
</html>