<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-06-12 08:05:00 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away /httpdocs/juanjo/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-06-12 08:05:59 --> 404 Page Not Found --> admin/login
ERROR - 2014-06-12 08:09:48 --> 404 Page Not Found --> admin/login
ERROR - 2014-06-12 08:09:53 --> 404 Page Not Found --> admin/index
ERROR - 2014-06-12 08:09:58 --> 404 Page Not Found --> admin/index
ERROR - 2014-06-12 08:10:17 --> 404 Page Not Found --> admin/index
ERROR - 2014-06-12 08:10:23 --> 404 Page Not Found --> admin/index
ERROR - 2014-06-12 09:37:36 --> Severity: Notice  --> Undefined property: Sesiones::$db /httpdocs/juanjo/application/libraries/Sesiones.php 16
ERROR - 2014-06-12 09:38:32 --> Severity: Notice  --> Undefined property: Sesiones::$load /httpdocs/juanjo/application/libraries/Sesiones.php 8
ERROR - 2014-06-12 09:38:59 --> Severity: Notice  --> Undefined property: Sesiones::$load /httpdocs/juanjo/application/libraries/Sesiones.php 8
ERROR - 2014-06-12 10:00:47 --> Severity: Notice  --> Undefined property: Sesiones::$load /httpdocs/juanjo/application/models/sesiones.php 8
ERROR - 2014-06-12 10:00:49 --> Severity: Notice  --> Undefined property: Sesiones::$load /httpdocs/juanjo/application/models/sesiones.php 8
ERROR - 2014-06-12 10:10:28 --> Severity: Notice  --> Undefined variable: _SESSION /httpdocs/juanjo/application/views/admin/login.php 44
ERROR - 2014-06-12 10:16:35 --> Severity: Notice  --> Undefined variable: _SESSION /httpdocs/juanjo/application/views/admin/login.php 44
ERROR - 2014-06-12 10:17:00 --> Severity: Notice  --> Undefined variable: _SESSION /httpdocs/juanjo/application/views/admin/login.php 44
ERROR - 2014-06-12 10:20:40 --> Severity: Notice  --> Undefined variable: _SESSION /httpdocs/juanjo/application/views/admin/login.php 45
ERROR - 2014-06-12 11:52:41 --> Severity: Notice  --> Undefined variable: _SESSION /httpdocs/juanjo/application/controllers/admin/admin.php 53
ERROR - 2014-06-12 11:56:26 --> Unable to load the requested class: session
ERROR - 2014-06-12 11:56:28 --> Unable to load the requested class: session
ERROR - 2014-06-12 12:05:54 --> Severity: Notice  --> Undefined variable: _SESSION /httpdocs/juanjo/application/controllers/admin/admin.php 62
ERROR - 2014-06-12 12:18:42 --> Severity: Notice  --> Undefined variable: menu_de_hoy /httpdocs/juanjo/application/views/admin/platos.php 45
ERROR - 2014-06-12 12:40:45 --> Severity: Notice  --> Undefined variable: loegado /httpdocs/juanjo/application/controllers/admin/admin.php 88
ERROR - 2014-06-12 12:41:22 --> Severity: Notice  --> Undefined variable: menu_hoy /httpdocs/juanjo/application/views/admin/ok.php 43
ERROR - 2014-06-12 12:41:30 --> Severity: Notice  --> Undefined variable: menu_hoy /httpdocs/juanjo/application/views/admin/platos.php 45
ERROR - 2014-06-12 12:42:03 --> Severity: Notice  --> Undefined variable: menu_hoy /httpdocs/juanjo/application/views/admin/platos.php 45
ERROR - 2014-06-12 12:42:42 --> Severity: Notice  --> Undefined variable: menu_hoy /httpdocs/juanjo/application/views/admin/platos.php 45
