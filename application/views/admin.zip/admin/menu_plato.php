<!DOCTYPE html>
<html lang="es">
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
</head>
<body>
<table width="100%">
<? foreach ($platos as $row) {?>
	<form action="" method="post">
	<tr>
		<td><?=$row -> plato ?></td>
		<td>>
	</tr>
	</form>
<? } ?>
</table>
</body>
</html>