<!DOCTYPE html>
<html lang="es">
<head>
<link href="<?=base_url()?>css/estilos.css" rel="stylesheet" type="text/css" />
<link href="<?=base_url()?>css/admin.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Raleway:400,700|Jura:400,300,500' rel='stylesheet' type='text/css'>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<style>
html {
	background: url(<?=base_url()?>img/fondos/fondo<?=rand(1,5);?>.jpg) no-repeat center center fixed; 
  	-webkit-background-size: cover;
  	-moz-background-size: cover;
  	-o-background-size: cover;
  	background-size: cover;
}
</style>
<title>Cafeteria de la Residencia Alfonso VIII -Usuarios registrados</title>
<meta name="description" content="Cafetería de la Residencia Universitaria Alfonso VIII, Valladolid. Donde podras encontrar menús sabrosos y un trato excepcional. Regentada por Juanjo, a quien querras ver.">
</head>
<body>
<div id="logo">
	Residencia Universitaria Alfonso VIII
</div>

<div id="centrado">
	<div id="contenido">
		<div id="menu_interior">
	    	<ul>
	    		<li><a href="#">platos</a></li>
	        	<li><a href="<?=base_url()?>index.php/admin/admin/menu">menu</a></li>
	            <li><a href="<?=base_url()?>index.php/admin/admin/frases">frases</a></li>
	            <li><a href="<?=base_url()?>index.php/admin/admin/precios">precios</a></li>
	        </ul>
	    </div>
	    <div id="sub_menu_interior">    
	        <ul>
	        	<li><a href="<?=base_url()?>index.php/admin/admin/platos/?opcion=1">añadir</a></li>
	        	<li>/</li>
	        	<li><a href="<?=base_url()?>index.php/admin/admin/platos/?opcion=2">ver todos platos</a></li>
	        </ul>
	    </div>
	    <div class="clear"></div>
	    <!-- contenido -->
	    <p><strong>Atenci&oacute;n</strong>: Si borras un plato lo eliminaras de todos los menus que lo contengan. Ten en cuenta esto ya que quizas lo que quieras es <strong>modificarlo</strong>.</p>
	    <br />
		<table width="100%">
			<tr>
				<td><strong>nombre</strong></td>
				<td><strong>vegetariano</strong></td>
				<td><strong>de regimen</strong></td>
				<td><strong>calorias</strong></td>
				<td><strong>hidratos</strong></td>
			</tr>
			<? foreach ($platos as $row) { ?>
				<tr>
					<td><?=$row -> plato?></td>
					<td><? if ($row -> vegetariano ==0) { ?>NO<? } else { ?>SI<? } ?></td>
					<td><? if ($row -> de_regimen ==0) { ?>NO<? } else { ?>SI<? } ?></td>
					<td><?=$row -> calorias ?></td>
					<td><?=$row -> hidratos?></td>
				</tr>
			<? $idplato = $row -> idplato; ?>
			<? } ?>
				<tr>
					<td colspan="5" align="center">
						<form action="<?=base_url()?>index.php/admin/admin/plato_borrar" method="post">
							<input type="hidden" name="id" value ="<?=$idplato?>" />
							<input type="hidden" name="borrar" value="1" />
							<input type="submit" name="enviar" value="eliminar plato" class="boton_form"/>
						</form>
					</td>
				</tr>
		</table>
	</div>
</div>

<div id="copyright">
	<a href="http://strascast.no-ip.info"><img src="http://strascast.no-ip.info/productos/strascast/img/strascast_font.png" height="10" alt="Copyright Strascast" /></a>
</div>
</body>
</html>