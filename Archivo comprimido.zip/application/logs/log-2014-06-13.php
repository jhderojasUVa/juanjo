<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-06-13 08:24:37 --> Severity: Notice  --> Undefined variable: menu_hoy /httpdocs/juanjo/application/views/admin/ok.php 43
ERROR - 2014-06-13 08:25:19 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=32 Broken pipe /httpdocs/juanjo/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-06-13 13:06:39 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 58
ERROR - 2014-06-13 13:06:39 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 63
ERROR - 2014-06-13 13:06:39 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 65
ERROR - 2014-06-13 13:07:21 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 58
ERROR - 2014-06-13 13:07:21 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 63
ERROR - 2014-06-13 13:07:21 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 65
ERROR - 2014-06-13 13:07:50 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 58
ERROR - 2014-06-13 13:07:51 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 63
ERROR - 2014-06-13 13:07:51 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 65
ERROR - 2014-06-13 13:09:48 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 58
ERROR - 2014-06-13 13:09:48 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 63
ERROR - 2014-06-13 13:09:48 --> Severity: Notice  --> Undefined variable: opcion /httpdocs/juanjo/application/views/admin/platos.php 65
ERROR - 2014-06-13 13:26:05 --> Severity: Notice  --> Undefined variable: row /httpdocs/juanjo/application/views/admin/platos.php 86
ERROR - 2014-06-13 13:26:05 --> Severity: Notice  --> Trying to get property of non-object /httpdocs/juanjo/application/views/admin/platos.php 86
ERROR - 2014-06-13 13:28:54 --> Severity: Notice  --> Undefined variable: nombre /httpdocs/juanjo/application/controllers/admin/admin.php 114
ERROR - 2014-06-13 13:28:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '. '', '122', '1')' at line 1
ERROR - 2014-06-13 13:30:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '. '0', '122', '1')' at line 1
ERROR - 2014-06-13 13:30:39 --> Query error: Table 'juanjo.menus' doesn't exist
