<? // Modelo de los menus
class Menu extends CI_Model {
	
	function __construct() {
        // Call the Model constructor
        parent::__construct();
		$this -> load -> database();
    }
	
	function ver_ultimo_menu(){
		// Funcion que devuelve un menu segun la fecha de hoy
		// Primero el "hoy"
		$hoy = date("Y-m-d");
		// La sentencia SQL de busqueda
		//$sql = "SELECT platos.plato menu.posicion FROM menu, platos WHERE menu.idplato=platos.idplato AND fecha='".$hoy."' ORDER BY menu.posicion";
		$sql="SELECT plato, posicion FROM platos INNER JOIN menu ON menu.idplato=platos.idplato WHERE menu.idplato=platos.idplato AND fecha='".$hoy."' ORDER BY menu.posicion";
		return $this -> db -> query($sql) -> result();
	}
	
	function ver_menu_fecha($fecha){
		// Funcion que devuelve un menu segun una fecha
		// La fecha ha de estar formateada AÑO-MES-DIA
		// La sentencia SQL de busqueda
		//$sql = "SELECT platos.plato FROM menu, platos WHERE menu.idplato=platos.idplato AND fecha='".$fecha."' ORDER BY menu.posicion";
		$sql="SELECT plato, posicion FROM platos INNER JOIN menu ON menu.idplato=platos.idplato WHERE menu.idplato=platos.idplato AND fecha='".$fecha."' ORDER BY menu.posicion";
		return $this -> db -> query($sql) -> result();
	}
	
	function add_plato($nombre, $vegetariano, $de_regimen, $calorias, $hidratos) {
		// Funcion para meter un plato en la base de datos
		$sql = "INSERT INTO platos (plato, vegetariano, de_regimen, calorias, hidratos) VALUES ('".$nombre."', '".$vegetariano."', '".$de_regimen."', '".$calorias."', '".$hidratos."')";
		$this -> db -> query($sql);
	}
	
	function ver_platos() {
		// Funcion que devuelve todos los platos
		$sql = "SELECT idplato, plato, vegetariano, de_regimen, calorias, hidratos FROM platos ORDER BY plato";
		return $this -> db -> query($sql) -> result();
	}
	
	function ver_un_plato($idplato) {
		// Funcion que devuelve UN plato
		// $idplato = el identificador del plato
		$sql = "SELECT idplato, plato, vegetariano, de_regimen, calorias, hidratos FROM platos WHERE idplato='".$idplato."' ORDER BY plato";
		return $this -> db -> query($sql) -> result();
	}
	
	function add_plato_menu ($idplato, $fecha, $posicion) {
		// Funcion que mete un plato en un menu segun un orden
		// idplato es el identificador del plato
		// La fecha ha de estar formateada AÑO-MES-DIA
		// posicion = 1 (primero), 2 (segundo), ....
		$sql = "INSERT INTO menu (idplato, fecha, posicion) VALUES ('".$idplato."', '".$fecha."', '".$posicion."')";
		$this -> db -> query($sql);
	}
	
	function borra_plato ($idplato) {
		// Funcion para borrar un plato
		// Necesario: IDplato (obviamente)
		// ATENCION, si se borra un plato, se borra de todos los menus, esto se hace por coherencia en la base de datos
		
		// Borramos el plato de los platos
		$sql = "DELETE FROM platos WHERE idplato='".$idplato."'";
		$this -> db -> query($sql);
		
		// Borramos el plato de los menus
		$sql = "DELETE FROM menu WHERE idplato='".$idplato."'";
		$this -> db -> query($sql);
	}
	
	function modifica_plato ($idplato, $plato, $vegetariano, $de_regimen, $calorias, $hidratos) {
		// Funcion generica para modificar un plato
		// Necesario: IDplato
		$sql = "UPDATE platos SET plato='".$plato."', vegetariano='".$vegetariano."', de_regimen='".$de_regimen."', calorias='".$calorias."', hidratos='".$hidratos."' WHERE idplato='".$idplato."'";
		$this -> db -> query($sql);
	}
	
	function borra_plato_menu ($idplato, $fecha, $posicion) {
		// Funcion que elimina un plato de un menu
		// $idplato = identificador del plato
		// $fecha = fecha del menu
		// $posicion = posicion en el menu, por si se ha puesto 2 veces
		$sql = "DELETE FROM menus WHERE $idplato='".$idplato."' AND fecha='".$fecha."' AND posicion='".$posicion."'";
		$this -> db -> query($sql);
	}
}
?>