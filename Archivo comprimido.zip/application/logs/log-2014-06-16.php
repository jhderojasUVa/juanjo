<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-06-16 08:14:27 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away /httpdocs/juanjo/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-06-16 08:15:01 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away /httpdocs/juanjo/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-06-16 08:15:01 --> Severity: Notice  --> Undefined variable: platos /httpdocs/juanjo/application/views/admin/platos.php 95
ERROR - 2014-06-16 08:43:20 --> 404 Page Not Found --> admin/frase_modificar
ERROR - 2014-06-16 08:45:09 --> 404 Page Not Found --> admin/frase_modificar
ERROR - 2014-06-16 09:05:23 --> Severity: Notice  --> Undefined variable: frases /httpdocs/juanjo/application/views/admin/frases_modificar.php 45
ERROR - 2014-06-16 09:05:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /httpdocs/juanjo/application/views/admin/frases_modificar.php 45
ERROR - 2014-06-16 09:16:49 --> Severity: Notice  --> Undefined property: stdClass::$idfrase /httpdocs/juanjo/application/views/admin/frases_modificar.php 49
ERROR - 2014-06-16 10:40:41 --> 404 Page Not Found --> admin/frase_borrar
ERROR - 2014-06-16 11:47:48 --> Severity: Notice  --> Undefined variable: texto /httpdocs/juanjo/application/controllers/admin/admin.php 235
ERROR - 2014-06-16 12:05:48 --> Severity: Notice  --> Trying to get property of non-object /httpdocs/juanjo/application/models/precio.php 15
ERROR - 2014-06-16 12:13:26 --> Severity: Notice  --> Undefined property: Admin::$precio /httpdocs/juanjo/application/controllers/admin/admin.php 305
ERROR - 2014-06-16 12:14:21 --> 404 Page Not Found --> admin/precio
