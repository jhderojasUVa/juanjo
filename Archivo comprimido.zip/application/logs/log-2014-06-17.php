<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-06-17 07:19:07 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away /httpdocs/juanjo/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2014-06-17 07:19:23 --> 404 Page Not Found --> admin/menu
ERROR - 2014-06-17 12:27:18 --> 404 Page Not Found --> ws/show_menu_json
