<!DOCTYPE html>
<html lang="es">
<head>
<link href="<?=base_url()?>css/estilos.css" rel="stylesheet" type="text/css" />
<link href="<?=base_url()?>css/admin.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Raleway:400,700|Jura:400,300,500' rel='stylesheet' type='text/css'>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<style>
html {
	background: url(<?=base_url()?>img/fondos/fondo<?=rand(1,5);?>.jpg) no-repeat center center fixed; 
  	-webkit-background-size: cover;
  	-moz-background-size: cover;
  	-o-background-size: cover;
  	background-size: cover;
}
</style>
<title>Cafeteria de la Residencia Alfonso VIII -Usuarios registrados</title>
<meta name="description" content="Cafetería de la Residencia Universitaria Alfonso VIII, Valladolid. Donde podras encontrar menús sabrosos y un trato excepcional. Regentada por Juanjo, a quien querras ver.">
</head>
<body>
<div id="logo">
	Residencia Universitaria Alfonso VIII
</div>

<div id="centrado">
	<div id="contenido">
		<div id="menu_interior">
	    	<ul>
	    		<li><a href="#">platos</a></li>
	        	<li><a href="<?=base_url()?>index.php/admin/admin/menu">menu</a></li>
	            <li><a href="<?=base_url()?>index.php/admin/admin/frases">frases</a></li>
	            <li><a href="<?=base_url()?>index.php/admin/admin/precios">precios</a></li>
	        </ul>
	    </div>
	    <div id="sub_menu_interior">    
	        <ul>
	        	<li><a href="<?=base_url()?>index.php/admin/admin/platos/?opcion=1">añadir</a></li>
	        	<li>/</li>
	        	<li><a href="<?=base_url()?>index.php/admin/admin/platos/?opcion=2">ver todos platos</a></li>
	        </ul>
	    </div>
	    <div class="clear"></div>
	    <!-- contenido -->
	    <? if (isset($menu_hoy) && count($menu_hoy)!=0) { ?>
	    <p><strong>Menu del d&iacute;a de hoy</strong></p>
	    	<table width="550">
	    	<? foreach ($menu_hoy as $row) { ?>
	    			<tr>
		    			<td width="100">De <?=$row -> posicion?></td>
		    			<td><?=$row -> plato?></td>
	    			</tr>
	    	<? } ?>
	    	</table>
	    <? } else if (isset($menu_hoy)) { ?>
	    <p>No hay men&uacute; para hoy.</p>
	    <p>Para añadir un men&uacute; pulse sobre <strong>men&uacute;</strong> situado sobre estas letras.</p>
	    <? } ?>
	    <? if (!isset($opcion)) { $opcion = 2; } ?>
	    <? if ($opcion==0) { ?>
	    	<h1><span class="titulo">Ayuda</span></h1>
	    	<p>Utilice el men&uacute; superior para añadir un plato.</p>
	    	<p>Si quiere modificar o borrar un plato, pulse sobre "ver todos platos", búsquelo y realice la opción oportuna con el.</p>
	    <? } ?>
	    <? if ($opcion==1) { ?>
	    <p>Rellene el siguiente formulario para insertar un nuevo plato que podr&aacute; seleccionar en el menu.</p>
	    <p>Recuerde que las unidades de carbono, 1 unidad son 10 gr de hidratos de carbono.</p>
	    <br />
		<table width="100%">
			<tr>
				<td><strong>nombre</strong></td>
				<td><strong>vegetariano</strong></td>
				<td><strong>de regimen</strong></td>
				<td><strong>calorias</strong></td>
				<td><strong>hidratos</strong></td>
			</tr>
				<form action="<?=base_url()?>index.php/admin/admin/plato_add" method="post" class="formulario">
				<tr>
					<td><input type="text" name="plato" placeholder="nombre del plato" /></td>
					<td><input type="checkbox" name="vegetariano" value="1"></td>
					<td><input type="checkbox" name="de_regimen" value="1"></td>
					<td><input type="text" name="calorias" placeholder="calorias del plato" /></td>
					<td><input type="text" name="hidratos" placeholder="unidades de hidratos de carbono" /></td>
				</tr>
				<tr>
					<td colspan="5" align="center">
						<input type="hidden" name="add" value="1" />
						<input type="submit" name="enviar" value="añadir plato" class="boton_form"/>
					</td>
				</tr>
				</form>
		</table>
	    <? } ?>
	    <? if ($opcion==2) { ?>
	    	<br />
	    	<? if (count($platos)!=0) { ?>
	    		<table width="100%">
	    			<tr>
	    				<td><strong>nombre</strong></td>
	    				<td><strong>vegetariano</strong></td>
	    				<td><strong>de regimen</strong></td>
	    				<td><strong>calorias</strong></td>
	    				<td><strong>hidratos</strong></td>
	    				<td></td>
	    			</tr>
	    			<? foreach ($platos as $row) { ?>
	    				<tr>
	    					<td><?=$row -> plato?></td>
	    					<td><? if ($row -> vegetariano ==0) { ?>NO<? } else { ?>SI<? } ?></td>
	    					<td><? if ($row -> de_regimen ==0) { ?>NO<? } else { ?>SI<? } ?></td>
	    					<td><?=$row -> calorias ?></td>
	    					<td><?=$row -> hidratos?></td>
	    					<td align="center"><span class="boton"><a href="<?=base_url()?>index.php/admin/admin/plato_borrar?id=<?=$row -> idplato?>">borrar</a></span> <span class="boton"><a href="<?=base_url()?>index.php/admin/admin/plato_modificar?id=<?=$row -> idplato?>">modificar</a></span></td>
	    				</tr>
	    			<? } ?>
	    		</table>
	    	<? } ?>
	    <? } ?>
	</div>
</div>

<div id="copyright">
	<a href="http://strascast.no-ip.info"><img src="http://strascast.no-ip.info/productos/strascast/img/strascast_font.png" height="10" alt="Copyright Strascast" /></a>
</div>
</body>
</html>